const fs = require('fs');
const { JSDOM } = require('jsdom');

const html = fs.readFileSync('public/index.html', 'utf8');
const script = fs.readFileSync('public/script.js', 'utf8');

const dom = new JSDOM(html, { runScripts: "outside-only" });
const window = dom.window;
const document = window.document;

// Mock window and document properties
window.alert = console.log;
window.history = { replaceState: () => {} };
window.fetch = async () => ({ ok: true, json: async () => ({}) });

try {
    window.eval(script);
    console.log("Script loaded successfully without throwing synchronous errors.");
} catch (e) {
    console.error("Error loading script:", e);
}
