import zipfile

files = [
    'api/index.js',
    'public/script.js',
    'public/index.html',
    'public/style.css',
    'package.json',
    'package-lock.json',
    'vercel.json',
]

with zipfile.ZipFile('upload_package.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for f in files:
        z.write(f)
        print(f'Added: {f}')

print('Done! upload_package.zip created.')
