const fs = require('fs');
const html = fs.readFileSync('public/index.html', 'utf8');
const script = fs.readFileSync('public/script.js', 'utf8');

// Find all IDs in HTML
const ids = new Set();
const regexId = /id="([^"]+)"/g;
let match;
while ((match = regexId.exec(html)) !== null) {
    ids.add(match[1]);
}

console.log("IDs found in HTML:", ids.size);

// Find all document.getElementById calls in script
const scriptIds = new Set();
const regexGetId = /document\.getElementById\(['"]([^'"]+)['"]\)/g;
while ((match = regexGetId.exec(script)) !== null) {
    scriptIds.add(match[1]);
}

console.log("IDs requested by script:", scriptIds.size);

const missingIds = [];
for (const id of scriptIds) {
    if (!ids.has(id)) {
        missingIds.push(id);
    }
}

console.log("IDs in script BUT NOT in HTML:", missingIds);
