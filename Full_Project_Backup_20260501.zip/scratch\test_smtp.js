const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 465,
    secure: true,
    auth: {
        user: 's33automail@gmail.com',
        pass: 'ffxkqlczsiwshfhh'
    }
});


const mailOptions = {
    from: 's33automail@gmail.com',
    to: 'spfst1@gmail.com', // Assuming this might be the user's email or a test one
    subject: 'SMTP Test Email',
    text: 'This is a test email to verify SMTP functionality.'
};

transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
        console.error("Send Error:", error);
    } else {
        console.log("Email sent successfully:", info.response);
    }
});

